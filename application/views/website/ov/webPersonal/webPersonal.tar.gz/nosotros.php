<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport"
	content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no" />
<title>Educate</title>

<!-- CSS  -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
	rel="stylesheet">
<link href="/template/materialize/css/materialize.css" type="text/css"
	rel="stylesheet" media="screen,projection" />
<link href="/template/materialize/css/style.css" type="text/css"
	rel="stylesheet" media="screen,projection" />
</head>
<body>
	<nav role="navigation">
		<div class="nav-wrapper container">
			<a id="logo-container" href="#" class="brand-logo"><img
				style="height: 2rem; width: 7rem;" class="responsive-img"
				src="/template/materialize/imagenes/logo.png"></img></a>
			<ul class="right hide-on-med-and-down">
				<li><a href="/ov/web/index?web=<?php echo $_GET['web'];?>">Home</a></li>
				<li><a href="#">Sobre Nosostros</a></li>
				<li><a href="http://oficinavirtual.educatenetwork.com/auth/login">Oficina
						Vitual</a></li>
				<li><a href="/ov/web/afiliar?web=<?php echo $_GET['web'];?>"
					onclick="afiliar()">Afiliarme</a></li>
			</ul>

			<ul id="nav-mobile" class="side-nav">
				<li><a href="#">Sobre Nosotros</a></li>
			</ul>
			<a href="#" data-activates="nav-mobile" class="button-collapse"><i
				class="material-icons">menu</i></a>
		</div>
	</nav>

	<div class="parallax-container valign-wrapper">
		<div class="section no-pad-bot">
			<div class="container">
				<div class="row center">
					<h5 class="header col s12 light"></h5>
				</div>
			</div>
		</div>
		<div class="parallax">
			<img src="/template/materialize/imagenes/bannerQuienes.jpg"
				alt="Unsplashed background img 3"
				style="transform: translate3d(-50%, 160px, 0px); display: block;">
		</div>
	</div>

	<div class="container">
		<div class="section">

			<!--   Icon Section   -->
			<div class="row">
				<div class="col s12 m8 offset-m2">
					<div class="icon-block">
						<h2 class="center brown-text">
							<i class="material-icons"></i>
						</h2>
						<h5 class="center-align">MISIÓN</h5>
						<p class="justify-align" style="text-align: justify;">EMPODERAR A
							TODO SOÑADOR ATREVIDO CON LOS CONOCIMIENTOS Y HERRAMIENTAS QUE
							NECESITA PARA TENER ÉXITO EN CUALQUIER TIPO DE NEGOCIO POR
							INTERNET Y EN SU VIDA, TRANSFORMANDO ASÍ A SOÑADORES DESBOCADOS
							EN EMPRESARIOS ENFOCADOS.</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="section">

			<!--   Icon Section   -->
			<div class="row">
				<div class="col s12 m8 offset-m2">
					<div class="icon-block">
						<h2 class="center brown-text">
							<i class="material-icons"></i>
						</h2>
						<h5 class="center-align">+ SOBRE NOSOTROS</h5>
						<p class="justify-align" style="text-align: justify;">En nuestras
							filas Corporativas encontrarás un excelente equipo de
							profesionales, con alta orientación a resultados, afán de
							superación, altas dosis de innovación para garantizar la
							evolución del modelo de gestión y acostumbrados al trabajo en
							equipo y colaboración los unos con los otros para entre todos
							formar Educate Network.</p>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col s12 m6">
					<div class="card-panel grey lighten-5 z-depth-1">
						<div class="row valign-wrapper">
							<div class="col s4">
								<img alt="" src="/template/materialize/imagenes/adrian.png"
									class="circle responsive-img" style="width: 15rem; height: 8rem;">
							</div>
							<div class="col s8">
								<span class="black-text">
									<p>
										ADRIAN ALVAREZ <br> <i class="red-text">C.E.O.</i>
									</p>
								</span>
							</div>
						</div>
					</div>
				</div>
				
				<div class="col s12 m6">
					<div class="card-panel grey lighten-5 z-depth-1">
						<div class="row valign-wrapper">
							<div class="col s4">
								<img alt="" src="/template/materialize/imagenes/pedro.jpg"
									class="circle responsive-img" style="width: 15rem; height: 8rem;">
							</div>
							<div class="col s8">
								<span class="black-text">
									<p>
										PEDRO PINEDA <br> <i class="red-text">C.E.O.</i>
									</p>
								</span>
							</div>
						</div>
					</div>
				</div>
				
				<div class="col s12 m6">
					<div class="card-panel grey lighten-5 z-depth-1">
						<div class="row valign-wrapper">
							<div class="col s4">
								<img alt="" src="/template/materialize/imagenes/leonardo.jpg"
									class="circle responsive-img" style="width: 15rem; height: 8rem;">
							</div>
							<div class="col s8">
								<span class="black-text">
									<p>
										LEONARDO LUJAN <br> <i class="red-text">Director de Educación.</i>
									</p>
								</span>
							</div>
						</div>
					</div>
				</div>
				
				<div class="col s12 m6">
					<div class="card-panel grey lighten-5 z-depth-1">
						<div class="row valign-wrapper">
							<div class="col s4">
								<img alt="" src="/template/materialize/imagenes/rafael.jpg"
									class="circle responsive-img" style="width: 15rem; height: 8rem;">
							</div>
							<div class="col s8">
								<span class="black-text">
									<p>
										RAFAEL PÉREZ <br> <i class="red-text">Director de Marketing</i>
									</p>
								</span>
							</div>
						</div>
					</div>
				</div>
				
				<div class="col s12 m6">
					<div class="card-panel grey lighten-5 z-depth-1">
						<div class="row valign-wrapper">
							<div class="col s4">
								<img alt="" src="/template/materialize/imagenes/lian.jpg"
									class="circle responsive-img" style="width: 15rem; height: 8rem;">
							</div>
							<div class="col s8">
								<span class="black-text">
									<p>
										LIANGELY SANCHEZ   <br> <i class="red-text">Herramientas Digitales.</i>
									</p>
								</span>
							</div>
						</div>
					</div>
				</div>
				
				<div class="col s12 m6">
					<div class="card-panel grey lighten-5 z-depth-1">
						<div class="row valign-wrapper">
							<div class="col s4">
								<img alt="" src="/template/materialize/imagenes/vic.png"
									class="circle responsive-img" style="width: 15rem; height: 8rem;">
							</div>
							<div class="col s8">
								<span class="black-text">
									<p>
										VIC CURIEL<br> <i class="red-text">Inglés Básico.</i>
									</p>
								</span>
							</div>
						</div>
					</div>
				</div>
				
				<div class="col s12 m6">
					<div class="card-panel grey lighten-5 z-depth-1">
						<div class="row valign-wrapper">
							<div class="col s4">
								<img alt="" src="/template/materialize/imagenes/paola.jpg"
									class="circle responsive-img" style="width: 15rem; height: 8rem;">
							</div>
							<div class="col s8">
								<span class="black-text">
									<p>
										PAOLA OCARRANZA <br> <i class="red-text">Vocabulario Express.</i>
									</p>
								</span>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	<div class="parallax-container valign-wrapper" >
		<div class="section no-pad-bot">
			<div class="container">
				<div class="row center">
					<h5 class="header col s12 light"></h5>
				</div>
			</div>
		</div>
		<div class="parallax yellow">
			<img src="/template/materialize/imagenes/logo.png"
				alt="Educate Netowork"
				style=" height: 10rem; width: 10rem;">
		</div>
	</div>


	<div class="container">
		<div class="row">
		<h1 ALIGN="center">APRENDE HABILIDADES Y HERRAMIENTAS PROFESIONALES PARA CONSTRUIR E IMPULSAR TU NEGOCIO EN INTERNET.</h1>
			<div class="col s12 m6 l6">
				<div class="section" ALIGN="justify">
					<img alt="" src="/template/materialize/imagenes/razonEducate.jpg" class="responsive-img" style="width: 30rem; height: 20rem;">
					<i>¿CUÁL ES LA RAZÓN DE SER DE EDÚCATE NETWORK? </i><br><br>
					Estamos aquí para empoderarte con todos los conocimientos y herramientas que necesitas para tener éxito en cualquier tipo de negocio que hagas en Internet.
					A veces tenemos muchos conocimientos y herramientas, pero no sabemos cómo emplearlas de manera efectiva para obtener resultados.<br> 
					<br>Otras veces no tenemos ni conocimientos ni herramientas, y aunque sí tenemos muchas ideas y ganas de triunfar, no sabemos qué necesitamos ni cómo empezar.
					Nuestro trabajo es hacer tu vida más fácil en ambos casos, y por eso estás aquí.
				</div>
				
				<div class="section" ALIGN="justify">
					<img alt="" src="/template/materialize/imagenes/uniserNetowrk.jpg" class="responsive-img" style="width: 30rem; height: 20rem;">
					<i>¿DE QUÉ TE SERVIRÍA UNIRTE A EDÚCATE NETWORK?  </i><br><br>
					Por medio de nuestro sistema de educación y autoformación, te desarrollaremos como profesional de los negocios para que logres impulsar tu proyecto de manera efectiva. Te diferenciarás de tu competencia y atraerás con mayor facilidad a tus clientes potenciales.
					<br><br>
					De esta manera, te devolveremos la capacidad de soñar y la seguridad de estar haciendo bien las cosas. Así dejarás de sentirte incómodo a la hora de hablar con los demás acerca de “cómo va tu negocio” y querrás contarle a todos el éxito que tienes.
					
				</div>
				
				<div class="section" ALIGN="justify">
					<img alt="" src="/template/materialize/imagenes/queEncuentras.jpg" class="responsive-img" style="width: 30rem; height: 20rem;">
					<i>¿QUÉ ENCONTRARÁS EN EDÚCATE NETWORK? </i><br><br>
					En nuestra plataforma encontrarás capacitaciones sencillas de entender, que se mantienen en constante actualización y están dispuestas de manera estratégica para que puedas observar resultados en tu negocio, y en tu vida, a corto o mediano plazo. No podía ser de otra manera, ya que estás en la primera red de mercadeo en Latinoamérica donde el principal producto es la educación..
				</div>
				
			</div>
			
			<div class="col s12 m6 l6">
				<div class="section" ALIGN="justify">
					<img alt="" src="/template/materialize/imagenes/queesEducate.png" class="responsive-img" style="width: 30rem; height: 30rem;">
					<i>¿QUÉ ES EDÚCATE NETWORK? </i><br><br>
					Es una empresa legalmente constituida en Estados Unidos enfocada en desarrollarte en los aspectos más importantes que necesitas para ser un emprendedor integral de la Internet. Con el ingrediente extra de permitirte generar ingresos simplemente invitando a otros a tomar nuestras capacitaciones, y promocionando nuestras herramientas digitales.
					<br><br>
					De esta manera, el simple hecho de capacitarte en Edúcate Network te puede llevar a vivir el “plan A” de tu vida y lograr la libertad financiera.
				</div>
				
				<div class="section" ALIGN="justify">
					<img alt="" src="/template/materialize/imagenes/utilEducate.jpg" class="responsive-img" style="width: 30rem; height: 20rem;">
					<i>¿PARA QUIÉN ES ÚTIL EDÚCATE NETWORK?</i><br><br>
					Para estudiantes, emprendedores, networkers, profesionales independientes, empresarios pymes, y cualquier persona en Latinoamérica que tenga un mensaje y lo quiera masificar en el mundo a través de la Internet.
				</div>
				
			</div>
		</div>
	</div>

	<div class="parallax-container valign-wrapper">
		<div class="section no-pad-bot">
			<div class="container">
				<div class="row">
					<div class="header col l5 s12 center">
						<h3><font color="black">ADRIAN ALVAREZ</font></h3>
						<i><font color="black">Enseñar| Ayudar | Proper</font></i>
					</div>
				</div>
			</div>
		</div>
		<div class="parallax black">
			<img src="/template/materialize/imagenes/adrian.png"
				alt="Adrian"
				style="transform: translate3d(-50%, 160px, 0px); display: block;">
		</div>
	</div>
	
	<div class="container">
		<div class="section">

			<div class="row">
				<div class="col l6 s12" align="justify">
					<p>Yo nací en México, y desde pequeño soy amante del fútbol. Así, desde muy pronto en mi vida entendí el valor del trabajo en equipo. Sin embargo, como a muchos latinos me tocó vivir etapas muy duras y sobreponerme a ellas.</p>

					<p>Para resumírtelo, pasé por la etapa de tener problemas con mi pareja por situaciones económicas que nos tenían tensos y estresados. Incluso me vi en la situación de quedarme sin empleo en momentos en que tenía esa creencia popular de que mi pago mensual fijo era algo seguro que me permitiría vivir mejor.</p>

					<p>En fin, he experimentado la terrible sensación de impotencia de no tener cómo mantener a mi familia.</p>

					<p>Fue así como llegué a conocer el mundo de las redes de mercadeo. Del MLM me enamoré al ver que el verdadero negocio está en crecer y ayudar a crecer a otras personas. Y es que nada es más maravilloso que transformar las vidas de otros, y definitivamente este es el mejor vehículo para lograrlo.</p>

					<p>En mi caso, el MLM me permitió darle a mi familia la vida que siempre quise darles. Pero sé muy bien que esta no es una realidad común en todas las personas que hacen este, o cualquier otro, tipo de negocio por Internet. De hecho, la probabilidad de éxito es del 5%. Pero la razón, es la falta de capacitación y herramientas correctas. El positivismo nunca es suficiente. Existe un proverbio japonés que explica mucho lo que sucede en los negocios por Internet, dice: “Desconocer una verdad me hace esclavo de una mentira”.</p>

					<p>Edúcate Network nació originalmente como un curso que se destinaba a ayudar, y darle a conocer VERDADES, a un grupo de personas que realizaban negocios por Internet sin lograr el éxito. Luego, surgió la idea de dar comisiones a quienes trajeran a más estudiantes, hasta que llegó a convertirse en una red de mercadeo que, con un generoso plan de compensación y bonificaciones, te permite capacitarte y simultáneamente generar ingresos a corto, mediano y largo plazo.</p>
					
					<p>He descubierto que mi pasión es emprender proyectos de ayuda social. De hecho, tengo otro proyecto de inversiones en real state, donde ayudo a familias a lograr sus sueños de tener su casa propia. Y al entregar las llaves de su casa, y ver la alegría destellante en sus rostros, entiendo perfectamente lo que sienten porque viví en carne propia las dificultades de alcanzar este logro para un latino. Con Edúcate Network, mi anhelo es ayudar a todos nuestros networkers a terminar bien la carrera y logar ese éxito por el que tanto luchan. Es por ello, que el premio final al terminar la carrera en Edúcate Network es una casa de lujo.</p>
					
					<p>Por otro lado, siento que tengo una deuda con la vida pues mi padre vivió en un orfanatorio cuando era niño, y he escuchado de su boca todo lo que vivió en ese lugar. Y a pesar de que él nunca tuvo un padre, siempre fue un excelente padre para mí. Me ayudó a crecer como empresario, como persona y como padre. Por eso, con Edúcate Network mientras ayudamos a personas a crecer personal y económicamente, al mismo tiempo ayudamos a niños huérfanos que viven en un orfanatorio a que reciban la atención, educación y el cariño que necesitan. Porque al darle amor a estos pequeños, siento en mi corazón que estoy a dando amor a mi propio padre en su niñez.</p>
					
					<p>Eso es lo que me hace despertar cada mañana y trabajar con pasión en esta hermosa empresa. Espero que me permitas ayudarte y que me ayudes a dejar una huella imborrable en quienes más lo necesitan.</p>
					
					<p>Un abrazo y saludos Atte:</p>
					
					<p>Adrian Alvarez</p>
				</div>
				
				<div class="col l6 s12">
					<img class="responsive-img" src="/template/materialize/imagenes/adrian_1.jpg" alt="Adrian">
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<img class="responsive-img" src="/template/materialize/imagenes/adrian_2.jpg" alt="Adrian">
				</div>
			</div>
		</div>
	</div>
	
	<footer class="page-footer white">
		<div>
			<div class="row">
				<div class="col l6 s12 center">
					<div class="row">
						<div class="col s12">
							<img alt="" src="/template/materialize/imagenes/logo.png"
								style="height: 10rem; width: 15rem;">
						</div>
						<div class="col l4 s12">
							<h5 class="">
								<i class="large material-icons">phone</i>
							</h5>
							<p class="">01-8000</p>
						</div>
						<div class="col l4 s12">
							<h5 class="">
								<i class="large material-icons">email</i>
							</h5>
							<p class="">INFO@EDUCATENETWORK.COM</p>
						</div>
						<div class="col l4 s12 ">
							<h5 class="">
								<i class="large material-icons">home</i>
							</h5>
							<p class="">
								135 S. SIERRA ST. <br> OAKDALE, CA
							</p>
						</div>
					</div>
				</div>
				<div class="col l6 s12">
					<iframe
						src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3154.0102828711065!2d-120.84777248518891!3d37.76635707976101!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8090f9cbeb4a62eb%3A0x142e6d6ca29594df!2s135+S+Sierra+Ave%2C+Oakdale%2C+CA+95361%2C+EE.+UU.!5e0!3m2!1ses-419!2sco!4v1475067032940"
						width="620px" height="400rem" style="border: 0" allowfullscreen></iframe>
				</div>
			</div>
		</div>
	</footer>


	<!--  Scripts-->
	<script src="/template/materialize/js/jquery-2.1.1.min.js"></script>
	<script src="/template/materialize/js/materialize.js"></script>
	<script src="/template/materialize/js/init.js"></script>

	<script>
		$(document).ready(function(){
			$("select").material_select();
			$('.datepicker').pickadate();
			$('.dropdown-buton').dropdown();
			$('.button-collapse').sideNav();
			$('.slider').slider();
			$('.materialboxed').materialbox();
			}
		);

		function afiliar(){

		}
	</script>

</body>
</html>
